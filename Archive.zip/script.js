// script.js

//https://www.w3schools.com/html/html_forms.asp
//https://developer.mozilla.org/en-US/docs/Learn_web_development/Extensions/Forms/Sending_and_retrieving_form_data

// Array of album objects with title, artist, year, cover, and URL
const albums = [
    {title: 'Wishbone', artist: 'Conan Gray', year: '2025', img: 'music/Conan Gray - Wishbone (2025)/cover.jpg'}
]

// Array of song objects with album, title, and number
const songs = [
    { album: 'Wishbone', title: 'Actor', url: 'music/Conan Gray - Wishbone (2025)/01. Conan Gray - Actor.flac', img: 'music/Conan Gray - Wishbone (2025)/cover.jpg' },
    { album: 'Wishbone', title: 'This Song', url: 'music/Conan Gray - Wishbone (2025)/02. Conan Gray - This Song.flac', img: 'music/Conan Gray - Wishbone (2025)/cover.jpg' },
    { album: 'Wishbone', title: 'Vodka Cranberry', url: 'music/Conan Gray - Wishbone (2025)/03. Conan Gray - Vodka Cranberry.flac', img: 'music/Conan Gray - Wishbone (2025)/cover.jpg' },
    { album: 'Wishbone', title: 'Romeo', url: 'music/Conan Gray - Wishbone (2025)/04. Conan Gray - Romeo.flac', img: 'music/Conan Gray - Wishbone (2025)/cover.jpg' },
    { album: 'Wishbone', title: 'My World', url: 'music/Conan Gray - Wishbone (2025)/05. Conan Gray - My World.flac', img: 'music/Conan Gray - Wishbone (2025)/cover.jpg' },
    { album: 'Wishbone', title: 'Class Clown', url: 'music/Conan Gray - Wishbone (2025)/06. Conan Gray - Class Clown.flac', img: 'music/Conan Gray - Wishbone (2025)/cover.jpg' },
    { album: 'Wishbone', title: 'Nauseous', url: 'music/Conan Gray - Wishbone (2025)/07. Conan Gray - Nauseous.flac', img: 'music/Conan Gray - Wishbone (2025)/cover.jpg' },
    { album: 'Wishbone', title: 'Caramel', url: 'music/Conan Gray - Wishbone (2025)/08. Conan Gray - Caramel.flac', img: 'music/Conan Gray - Wishbone (2025)/cover.jpg' },
    { album: 'Wishbone', title: 'Connell', url: 'music/Conan Gray - Wishbone (2025)/09. Conan Gray - Connell.flac', img: 'music/Conan Gray - Wishbone (2025)/cover.jpg' },
    { album: 'Wishbone', title: 'Sunset Tower', url: 'music/Conan Gray - Wishbone (2025)/10. Conan Gray - Sunset Tower.flac', img: 'music/Conan Gray - Wishbone (2025)/cover.jpg' },
    { album: 'Wishbone', title: 'Eleven Eleven', url: 'music/Conan Gray - Wishbone (2025)/11. Conan Gray - Eleven Eleven.flac', img: 'music/Conan Gray - Wishbone (2025)/cover.jpg' },
    { album: 'Wishbone', title: 'Care', url: 'music/Conan Gray - Wishbone (2025)/12. Conan Gray - Care.flac', img: 'music/Conan Gray - Wishbone (2025)/cover.jpg' }
    // Add more songs here
];

// Get references to the album cover, audio player, and playlist
const albumCover = document.getElementById('albumCover');
const audioPlayer = document.getElementById('audioPlayer');
const playlist = document.getElementById('playlist');

// Function to create playlist items
function createPlaylist() {
    songs.forEach((song, index) => {
        const album = albums.find(({ title }) => title === song.album);
        const li = document.createElement('li');
        li.textContent = song.title.concat(' (', song.album, ') by ', album.artist);
        li.classList.add('playlist-item');
        li.dataset.index = index; // Store song index in the dataset
        playlist.appendChild(li);
    });
}

// Function to handle song selection
function selectSong(index) {
    const song = songs[index];
    const album = albums.find(({ title }) => title === song.album);
    albumCover.src = album.img;
    audioPlayer.src = song.url;
    audioPlayer.play();

    // Update the active class on playlist items
    document.querySelectorAll('.playlist-item').forEach((item) => {
        item.classList.remove('active');
    });
    document.querySelector(`.playlist-item[data-index="${index}"]`).classList.add('active');

    // Autoplay next song
    const nextsong = Number(index)+1;
    audioPlayer.addEventListener("ended", (event) => {
        console.log("Audio completed.");
        autoplayNextSong(nextsong);
    });
}

// Function to handle autoplay
function autoplayNextSong(index) {
    if (index == songs.length) {
        selectSong(0)
    } else {
        selectSong(index)
    }
}

// Event listener for playlist item clicks
playlist.addEventListener('click', (event) => {
    if (event.target && event.target.classList.contains('playlist-item')) {
        const index = event.target.dataset.index;
        selectSong(index);
    }
});

// Search Function
function searchFunction() {
            let input = document.getElementById("song").value.toLowerCase();
            let items = document.querySelectorAll("#playlist li");
            items.forEach(item => {
                if (item.innerHTML.toLowerCase().includes(input)) {
                    item.style.display = "";
                } else {
                    item.style.display = "none";
                }
            });
        }

// Initialize playlist
createPlaylist();
